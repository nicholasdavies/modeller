# This line will install the "remotes" package, which is needed to install
# the "modeller" package that will be demonstrated in the course.
install.packages("remotes")

# This line will install the "modeller" package.
remotes::install_github("nicholasdavies/modeller")

# This line will open a Shiny app with an example SIR model.
modeller::show_model(modeller::sir_model())
