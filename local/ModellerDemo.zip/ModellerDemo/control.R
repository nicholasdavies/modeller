# Modelling the first and second waves of SARS-CoV-2 in the UK
# SEIRD model
# Includes Google mobility

library(modeller)

# Compartments with initial conditions
init <- list(
    S = 68000000, # Initial susceptibles
    E = 40,       # Initial exposed
    I = 0,        # Initial infected
    R = 0,        # Initial recovered
    M = 0,        # Recovery to death
    D1 = 0,       # Death delay 1
    D2 = 0,       # Death delay 2
    D3 = 0,       # Death final
    total_infections = 0, # Total infections over time
    total_deaths = 0      # Total deaths over time
)

# Load data
mobility = data.table::fread("./mobility.csv")
deaths = data.table::fread("./deaths.csv")


# Model parameters
params <- list(
    latent_period = 2.5,    # Duration of latent period (days)
    infectious_period = 5,  # Duration of infectious period (days)
    IFR1 = 1.5,             # IFR at start of pandemic
    IFR2 = 0.75,            # IFR after dexamethasone and treatment improvements
    R0 = 2.25,              # Basic reproduction number
    mobility_a = 0.5,       # Mobility parameter a
    mobility_b = 0.5,       # Mobility parameter b
    death_delay = 18,       # Delay to death
    lockdown_start = 75,    # Start of lockdown day
    time = 304              # Total simulation length
)

# Model equations
equations <- function()
{
    # Calculate IFR
    if (t < 150) {
        IFR <- IFR1
    } else if (t < 200) {
        IFR <- IFR1 + (IFR2 - IFR1) * (t - 150) / 50
    } else {
        IFR <- IFR2
    }
    
    # R0 based on mobility
    trel <- floor(min(304, max(-25, t + 75 - lockdown_start)))
    effect <- 1 - mobility_a * (1 - (mobility[trel == time, activity] ^ mobility_b))
    R0 <- R0 * max(0, effect)
    
    # Model intermediates
    infectious_rate <- 1 / latent_period
    rec_rate <- 1 / infectious_period
    death_rate <- 1 / death_delay
    beta <- R0 / infectious_period
    N <- S + E + I + R

    # Derivatives
    d(S) <- -beta * I/N * S
    d(E) <-  beta * I/N * S - infectious_rate * E
    d(I) <-                   infectious_rate * E - rec_rate * I
    d(R) <-                                         rec_rate * I * (1 - IFR/100)
    d(M) <-                                         rec_rate * I * (IFR/100) - 3*death_rate * M
    d(D1) <-                                                                   3*death_rate * M  - 3*death_rate * D1
    d(D2) <-                                                                   3*death_rate * D1 - 3*death_rate * D2
    d(D3) <-                                                                   3*death_rate * D2
    d(total_infections) <- beta * I/N * S
    d(total_deaths) <- 3*death_rate * D2

    # Extra parameters to record
    record(R0 = R0)
    record(IFR = IFR)
    record(activity = mobility[trel == time, activity])
}

# Build model
m <- ode_model(init, params, equations, options = list(method = "rk4"))

# Model explorer
show_model(m, data = deaths, hide = c("M", "D1", "D2", "D3"))

