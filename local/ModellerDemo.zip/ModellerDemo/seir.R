# A simple SEIR model

library(modeller)

# Compartments with initial conditions
init <- list(
    S = 68000000, # Initial susceptibles
    E = 0,        # Initial exposed
    I = 1,        # Initial infected
    R = 0         # Initial recovered
)

# Model parameters
params <- list(
    latent_period = 2.5,    # Duration of latent period (days)
    infectious_period = 5,  # Duration of infectious period (days)
    R0 = 2.25,              # Basic reproduction number
    time = 365              # Total simulation length
)

# Model equations
equations <- function()
{
    # Model intermediates
    infectious_rate <- 1 / latent_period
    rec_rate <- 1 / infectious_period
    beta <- R0 / infectious_period
    N <- S + E + I + R

    # Derivatives
    d(S) <- -beta * I/N * S
    d(E) <-  beta * I/N * S - infectious_rate * E
    d(I) <-                   infectious_rate * E - rec_rate * I
    d(R) <-                                         rec_rate * I
}

# Build model
m <- ode_model(init, params, equations, options = list(method = "rk4"))

# Model explorer
show_model(m)

